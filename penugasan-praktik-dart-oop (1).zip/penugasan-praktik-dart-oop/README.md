# Penugasan Praktik Pertemuan 3
## Dasar OOP di Dart: Simulasi Karakter Game

File program utama: `bin/main.dart`

## Menjalankan program
Pastikan Dart SDK sudah terpasang, lalu jalankan dari folder proyek:

```bash
dart run bin/main.dart
```

Program menerapkan:
- Class `Karakter`
- Encapsulation melalui `_healthPoint` dan getter `sisaDarah`
- Inheritance melalui class `Healer`
- Simulasi serangan dan pemulihan darah
